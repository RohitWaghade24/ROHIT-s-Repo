package com.greatlearning.service;

public interface CredService {
	generateEmailId(Sring firstname, String lastname, String dept);
	String generatePassword();
	void showDetails(Employee e1);
	

}
