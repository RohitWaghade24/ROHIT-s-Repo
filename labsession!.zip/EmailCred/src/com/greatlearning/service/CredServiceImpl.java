package com.greatlearning.service;

import com.greatlearning.model.Employee;

public class CredServiceImpl implements CredService{

	@Override
	public String generateEmailId(Sring firstname, String lastname, String dept) {
		
		return firstname+lastname+"@"+".gl.com"
		
		
		
	}

	@Override
	public String generatePassword() {
		String caps="ABCDEFGHIJKLMNOPQRSTUVWXYZ";
		String lower="abcdefghijklmnopqrstuvwxyz";
		String nums="0123456789";
		String spclchars="!@#$%^&*()";
		
		String combined=caps+lower+nums+spclchars;
		
		String mypass="";
		Random random=new Random();
		
		for(int i=0,i<8,i++)
		{
		mypass=mypass+String.valueOf(combined.charAt(random.nextInt(combined.length())))
		}
			return mypass;  
		}
		
	}

	@Override
	public void showDetails(Employee e1) {
		System.out.println("Employee First Name is"+e1.getFirstname());
		System.out.println("Employee Last Name is"+e1.getLastname());
		System.out.println("Employee Email Name is"+e1.getEmailname());
		System.out.println("Employee Password Name is"+e1.getPasswordname());
		
		
	}

}
